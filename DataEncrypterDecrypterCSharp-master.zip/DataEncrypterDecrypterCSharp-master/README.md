# DataEncrypterDecrypterCSharp
Basi Cryptography technique in C#. Here is complete explanation http://www.janaks.com.np/data-encryption-and-decryption-in-c/
